    <?php
    include 'header.php';
    include 'conexaoBD.php';
    include 'Usuario.php';
    ?>

    <head>
        <meta charset="utf-8">
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <title>DevFolio Bootstrap Portfolio Template - Blog Single</title>
        <meta content="" name="description">
        <meta content="" name="keywords">
        <!-- Favicons -->
        <link href="assets/img/favicon.png" rel="icon">
        <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
        <!-- Vendor CSS Files -->
        <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
        <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
        <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
        <!-- Template Main CSS File -->
        <link href="assets/css/style.css" rel="stylesheet">
        <!-- =======================================================
            * Template Name: DevFolio - v4.10.0
            * Template URL: https://bootstrapmade.com/devfolio-bootstrap-portfolio-html-template/
            * Author: BootstrapMade.com
            * License: https://bootstrapmade.com/license/
            ======================================================== -->
    </head>
    <div class="hero hero-single route bg-image" style="background-image: url(assets/img/overlay-bg.jpg)">
        <div class="overlay-mf"></div>
        <div class="hero-content display-table">
            <div class="table-cell">
                <div class="container">
                    <h2 class="hero-title mb-4">Cadastro</h2>
                </div>
            </div>
        </div>
    </div>

    <body>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Validar se o campo de nome foi preenchido
            if (empty($_POST['nome'])) {
                $errors[] = 'O campo nome é obrigatório.';
            }

            // Validar se o campo de e-mail foi preenchido e tem um formato válido
            if (empty($_POST['email']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
                $errors[] = 'O campo de e-mail é obrigatório e deve ter um formato válido.';
            }

            // Validar se o campo de senha foi preenchido e tem pelo menos 4 caracteres
            if (empty($_POST['senha']) || strlen($_POST['senha']) < 4) {
                $errors[] = 'O campo de senha é obrigatório e deve ter pelo menos 4 caracteres.';
            }

            // Se não houver erros de validação, salvar as informações no banco de dados e redirecionar para a página de confirmação
            if (empty($errors)) {
                // Substitua estas linhas pelo código que salva as informações no banco de dados
                $nome = $_POST['nome'];
                $email = $_POST['email'];
                $senha = $_POST['senha'];
                echo "<br><div style='margin-left: 550px'><p>Nome: $nome</p>";
                echo "<p>E-mail: $email</p>";
                // Verificar se o usuário já existe

                $sql = "SELECT * FROM usuario WHERE nome='$nome' OR email='$email'";
                $result = $mysql->query($sql);

                if ($result->num_rows > 0) {
                    echo "<b>Usuário já existe!</b>" ?><br><br><a href="#" onclick="history.back()">Voltar</a>
                    <?php
                } else {
                    // Se o usuário não existe, inserir os dados no banco de dados
                    $sql = "INSERT INTO usuario (nome, email, senha) VALUES ('$nome', '$email', '$senha')";

                    if ($mysql->query($sql)) {
                        echo "<b>Cadastro efetuado com sucesso!</b>"; ?><br><br><a href="#" onclick="history.back()">Voltar</a> </div><?php
                    } else {
                    
                        echo "Erro ao cadastrar: " . $mysql->error; ?><br><br><a href="#" onclick="history.back()">Voltar</a> </div><?php
                    }
                }
            }
            else{
                foreach ($errors as $error) {
                    echo "<div style='margin-left: 550px'><p>$error</p></div>";
                }
                ?> <br><br><div style='margin-left: 550px'><a href="#" onclick="history.back()">Voltar</a><?php
            }
        }                                                                                                                                                                                                                            

                                                                                                                                                                                                                                        

        ?>