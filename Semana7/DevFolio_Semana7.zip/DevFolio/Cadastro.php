        <?php
        include 'header.php';
        include 'conexaoBD.php';
        include 'Usuario.php';
        
        ?>
        

        <head>
        <meta charset="utf-8">
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
       
        <title>DevFolio Bootstrap Portfolio Template - Blog Single</title>
        <meta content="" name="description">
        <meta content="" name="keywords">

        <!-- Favicons -->
        <link href="assets/img/favicon.png" rel="icon">
        <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

        <!-- Vendor CSS Files -->
        <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
        <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
        <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

        <!-- Template Main CSS File -->
        <link href="assets/css/style.css" rel="stylesheet">

        <!-- =======================================================
        * Template Name: DevFolio - v4.10.0
        * Template URL: https://bootstrapmade.com/devfolio-bootstrap-portfolio-html-template/
        * Author: BootstrapMade.com
        * License: https://bootstrapmade.com/license/
        ======================================================== -->
        </head>

        <div class="hero hero-single route bg-image" style="background-image: url(assets/img/overlay-bg.jpg)">
            <div class="overlay-mf"></div>
            <div class="hero-content display-table">
            <div class="table-cell">
                <div class="container">
                <h2 class="hero-title mb-4">Cadastro</h2>

                </div>
            </div>
            </div>
        </div>
        <body>
        <form class="myform" method="POST" action="resultadoCadastro.php">
    <?php session_start(); ?>
    <div class="form-group row" style="margin-top: 30px;">
        <label for="nome" class="col-sm-2 col-form-label my-label" style="margin-left: 250px;">Nome</label>
        <input type="text" class="form-control input-pequeno" id="nome" name="nome" placeholder="Nome" 
        style="margin-left: -120px; width: 600px; margin-bottom: 30px;">
    </div>

    <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label" style="margin-left: 250px;">Email</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="E-mail"
        style="margin-left: -120px; width: 600px; margin-bottom: 30px;">
    </div>

    <div class="form-group row"> 
        <label for="inputPassword3" class="col-sm-2 col-form-label" style="margin-left: 250px;">Senha</label>
        <input type="password" class="form-control" id="senha" name="senha" placeholder="Senha"
        style="margin-left: -120px; width: 600px; margin-bottom: 30px;">
    </div>

    <div class="form-group row">
        <button type="submit" class="btn btn-primary" style="margin-left:550px;  width: 150px;
        margin-bottom: 30px;">Cadastrar</button>
    </div>
</form>

        <?php
        include 'footer.php';
        ?>
            </form>
    </body>
            