<?php

class Artigo
{
    private $mysql;

    public function __construct(mysqli $mysql)
    {
        $this ->mysql = $mysql;
    }

    public function mostrarTodos(): array
    {
        $resultado = $this->mysql->query('select * from artigos');
        $artigos = $resultado->fetch_all(MYSQLI_ASSOC);
        return $artigos;
    }
    public function encontrarPorId(int $id):array
    {
        $buscarArtigo = $this->mysql->prepare("select * from artigos where id = ?");
        $buscarArtigo -> bind_param('s', $id);
        $buscarArtigo -> execute();
        $artigo = $buscarArtigo->get_result()->fetch_assoc();
        return $artigo;
    }
    public function encontrarCaminhoFotoPorId(int $id):array
    {
        $buscarArtigo = $this->mysql->prepare("SELECT caminho FROM `artigos` inner join fotos on artigos.id = ?");
        $buscarArtigo -> bind_param('s', $id);
        $buscarArtigo -> execute();
        $artigo = $buscarArtigo->get_result()->fetch_assoc();
        return $artigo;
    }
    
}
