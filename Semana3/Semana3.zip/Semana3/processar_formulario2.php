<!DOCTYPE html>
<html>
<head>
    <title>Processamento do Formulário GET</title>
</head>
<body>
    <h1>Processamento do Formulário GET</h1>
    
    <?php
    if (isset($_GET["nome"]) && isset($_GET["email"])) {
        $nome = $_GET["nome"];
        $email = $_GET["email"];
        
        echo "<p>Olá, $nome, tudo bem?</p>";
        echo "<p>Nome: $nome</p>";
        echo "<p>E-mail: $email</p>";
    } else {
        echo "<p>Dados não foram enviados.</p>";
    }
    ?>
    
    <a href="formulario.php">Voltar</a>
</body>
</html>
