<!DOCTYPE html>
<html>
<head>
    <title>Exemplo de Formulário com Bootstrap</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2>Formulário de Contato</h2>

    <?php
    require_once 'Formulario.php';

    $formulario = new Formulario('index.php');

    $formulario->adicionarCampo('text', 'nome', 'Nome', 'Digite seu nome');
    $formulario->adicionarCampo('text', 'email', 'E-mail', 'Digite seu e-mail');
    $formulario->adicionarCampo('textarea', 'mensagem', 'Mensagem', 'Digite sua mensagem aqui');

    $formulario->exibir();
    ?>

</div>

</body>
</html>
