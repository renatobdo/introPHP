<?php
class Person {
    private $firstName;
    private $lastName;
    private $age;

    public function __construct($firstName, $lastName, $age) {
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->age = $age;
    }

    public function getFullName() {
        return $this->firstName . ' ' . $this->lastName;
    }
    
    public function setName($nome) {
        if ($nome == "a"){
            $this->firsName = "nome inválido";
        }else{
            $this->firsName = $nome;
        }                
    }
    public function getAge() {
        return $this->age;
    }

    public function setAge($age) {
        if ($age >= 0) {
            $this->age = $age;
        }
    }
}


?>