<!DOCTYPE html>
<html>
<head>
    <title>Exemplo de Formulário com Método GET</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        
        .form-container {
            width: 500px;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 15px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1 class="text-center mb-4">Formulário com Método GET</h1>
        <form action="processar_formulario2.php" method="GET">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome:</label>
                <input type="text" class="form-control" id="nome" name="nome" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email:</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <button type="submit" class="btn btn-primary">Enviar</button>
        </form>
    </div>
</body>
</html>
