<?php
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    require_once "Pessoa.php";

    // Exemplo de uso

    $pessoa = new Person($_GET["nome"], $_GET["sobrenome"],
        $_GET["idade"]);
    echo "Nome: " . $pessoa->getFullName() . "<br>";
    echo "Idade: " . $pessoa->getAge() . " anos<br>";

    $pessoa->setAge(31);
    echo "Nova idade: " . $pessoa->getAge() . " anos<br>";
}