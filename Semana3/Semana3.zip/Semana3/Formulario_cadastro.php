<!DOCTYPE html>
<html>
<head>
    <title>Formulário em PHP</title>
</head>
<body>

<?php
if(isset($_POST['submit'])){
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    // Aqui você pode realizar qualquer ação com os dados do formulário, como salvar em um banco de dados ou enviar por email.
    echo $nome.", o formulário foi enviado com sucesso! Seu email é ".$email;
}
?>

<form method="POST" action="">
    <label for="nome">Nome:</label>
    <input type="text" name="nome" id="nome" required><br><br>

    <label for="email">Email:</label>
    <input type="email" name="email" id="email" required><br><br>

    <input type="submit" name="submit" value="Enviar">
</form>

</body>
</html>