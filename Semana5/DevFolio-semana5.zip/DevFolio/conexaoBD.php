<?php

$mysql = new mysqli('localhost', 'root', '', 'devfolio');
if ($mysql == false){
   
        echo "Erro de conexão com o banco de dados";
    }
  
    

?>